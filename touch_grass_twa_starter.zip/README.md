# Touch Grass — One-Click TWA Starter

This package gives you **everything** to publish your web game to the **Google Play Store** via **Trusted Web Activity (TWA)**.

## Contents
- `site/` → your **PWA site** (ready to deploy: `index.html`, `manifest.webmanifest`, `sw.js`, `images/`)
- `site/.well-known/assetlinks.json` → **placeholder** for Digital Asset Links (edit later)
- `twa/twa-manifest.json` → Bubblewrap config (edit host/package/startUrl)
- This README with copy‑paste commands

---

## A. Host your PWA for free (GitHub Pages)
1. Create a new public repo, e.g. `touch-grass`.
2. Upload **everything inside** `site/` to the repo root.
3. In **Settings → Pages**: set Source to `Deploy from a branch`, choose `main` and `/root`.
4. Your URL will be: `https://yourname.github.io/touch-grass/`

> If using **Netlify** instead: drag the `site/` folder onto the Netlify dashboard. Your URL will look like `https://touch-grass-xyz.netlify.app/`. If you do that, update the TWA config (`twa-manifest.json`) to use your Netlify host and startUrl (`/`).

---

## B. Digital Asset Links (required by TWA)
When you build/sign the Android app, you’ll get a **SHA256 certificate fingerprint** for your signing key.

1. Get the SHA-256 fingerprint (Bubblewrap prints it after `bubblewrap build`). Or use:
   ```bash
   keytool -list -v -keystore android.keystore -alias touchgrass
   ```
2. Edit `site/.well-known/assetlinks.json` and replace:
   - `package_name` → your app ID (e.g. `com.yourname.touchgrass`)
   - `REPLACE_WITH_YOUR_SHA256_FINGERPRINT` → your real SHA-256
3. Commit & deploy the updated `assetlinks.json` to your site (must be available at `https://<host>/.well-known/assetlinks.json`).

> GitHub Pages supports folders starting with a dot. Commit as-is.

---

## C. Build the Android app (Bubblewrap)
Install once:
```bash
npm i -g @bubblewrap/cli
```

Use the provided config:
```bash
cd twa
bubblewrap init --manifest=twa-manifest.json
# If you don't have a keystore, Bubblewrap can generate one from values in the file.
bubblewrap build
```

This creates an **Android App Bundle (.aab)** in `./android/`.

> If you change your final site URL or package ID, re-run `bubblewrap init` (or edit `twa-manifest.json` and rebuild).

---

## D. Play Console upload checklist
- Create a Google Play developer account (one-time $25).
- Create a new app → upload the **.aab** from Bubblewrap.
- Fill in Store listing (name, description, screenshots, 512×512 icon).
- Provide a **Privacy Policy URL** (simple page is fine if no data is collected).
- Data Safety form → select “no data collected” if true.
- Content rating questionnaire.
- Set production track and **Submit**.

---

## E. Common gotchas
- **404 on assetlinks.json** → ensure the file is at `https://<host>/.well-known/assetlinks.json` (no redirects).
- **Verification failed** → SHA-256 must match the **signing key** used for the uploaded AAB.
- **PWA install prompt missing** → ensure `manifest.webmanifest` + `sw.js` are both live and HTTPS.

---

## F. Change these values
Edit `twa/twa-manifest.json`:
- `"packageId"` → e.g., `com.yourname.touchgrass`
- `"host"` → `yourname.github.io` (or your Netlify/Vercel host without protocol)
- `"startUrl"` → `"/touch-grass/"` (GitHub Pages project path) or `"/"` for root sites
- `"appUrl"` → full URL to your game

Edit `site/.well-known/assetlinks.json`:
- `"package_name"` and `"sha256_cert_fingerprints"`

---

## Timestamps
Generated: 2025-09-10T05:00:52.302931Z
